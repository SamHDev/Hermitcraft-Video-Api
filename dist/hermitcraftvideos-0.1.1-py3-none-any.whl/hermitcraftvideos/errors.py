class HermitApiError(Exception):
    pass
class InvaildHermitName(Exception):
    pass